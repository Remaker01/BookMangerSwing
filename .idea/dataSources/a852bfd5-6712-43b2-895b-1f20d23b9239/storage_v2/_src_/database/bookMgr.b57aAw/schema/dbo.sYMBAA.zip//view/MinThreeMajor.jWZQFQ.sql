CREATE VIEW [dbo].[MinThreeMajor] AS select top 3 Population from Majorinfo order by Population
go

